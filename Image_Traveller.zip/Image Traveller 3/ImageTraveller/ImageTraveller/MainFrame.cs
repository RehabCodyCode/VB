using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ImageTraveller
{
    public partial class MainFrame : Form
    {
        MenuItem SubItem21;
        MenuItem SubItem22;
        MenuItem SubItem11;
        MenuItem SubItem2;
        MenuItem SubItem1;


        public MainFrame()
        {
            InitializeComponent();
            IsMdiContainer = true;
            InitializeMyMainMenu();
            Icon = new Icon(GetType(), "TravellerCat.ico");
        }
        public void LoadChildFrame()
        {
            ChildFrame chFrame;
            chFrame = new ChildFrame();
            chFrame.MdiParent = this;
            chFrame.Location = new Point(0, 0);
            chFrame.Show();
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
        }
        private void InitializeMyMainMenu()
        {
            EventHandler eh = new EventHandler(MenuClick);

            // Create the MainMenu and the menu items to add.
            MainMenu mainMenu1 = new MainMenu();

            SubItem2 = new MenuItem("&Options");
            SubItem21 = new MenuItem("Bouncing Selection",eh);
            SubItem22 = new MenuItem("Sliding Selection", eh);

            SubItem22.Checked = true;
            SubItem21.Checked = false;
            // Set the caption for the menu items.

            SubItem1 = new MenuItem("&File");
            SubItem11 = new MenuItem("O&pen", eh);
            SubItem1.MenuItems.Add(SubItem11);
            mainMenu1.MenuItems.Add(SubItem1);

            // Add 2 menu items to the MainMenu for displaying.
            mainMenu1.MenuItems.Add(SubItem2);
            SubItem2.MenuItems.Add(SubItem21);
            SubItem2.MenuItems.Add(SubItem22);
            SubItem2.Enabled = false;
            // Assign mainMenu1 to the form.
            Menu = mainMenu1;
        }

        void MenuClick(object obj, EventArgs ea)
        {
            MenuItem mI = (MenuItem)obj;
            String str = mI.Text;
            if (str == "Bouncing Selection")
            {
                int nChildern = MdiChildren.GetLength(0);
                if (nChildern != 0)
                {
                    for (int j = 0; j < nChildern; j++)
                    {
                        ChildFrame chFrame = (ChildFrame)MdiChildren[j];
                        chFrame.nIsBounce = 1;
                    }
                    SubItem22.Checked = false;
                    SubItem21.Checked = true;
                }
            }
            else if (str == "Sliding Selection")
            {
                int nChildern = MdiChildren.GetLength(0);
                for (int j = 0; j < nChildern; j++)
                {
                    ChildFrame chFrame = (ChildFrame)MdiChildren[j];
                    chFrame.nIsBounce = 0;
                }
                SubItem22.Checked = true;
                SubItem21.Checked = false;
            }
            else
            if (str == "O&pen")
            {
                LoadChildFrame();
                int nChildern = MdiChildren.GetLength(0);
                if(nChildern > 0)
                {
                    ChildFrame chFrame = (ChildFrame)MdiChildren[nChildern-1];
                    if (chFrame.img != null)
                        SubItem2.Enabled = true;
                    else
                        chFrame.Close();
                }
            }

        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
                Close();
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}