using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ImageTraveller
{
    public struct PaintStruct
    {
        public Graphics dc;
        public bool isPaint;
    };
    public partial class ChildFrame : CDrawDragRect
                                     //Form
    {
        public Image img;
        Image imgResize;
        public int nDblClick;
        public ChildDisplayForm childDisplayFrm;
        public string strImgPath;
        public ChildFrame()
        {
            InitializeComponent();
            Icon = new Icon(GetType(), "TravellerCat.ico");
            EnableContextMenu();
        }
        void EnableContextMenu()
        {
            EventHandler eh = new EventHandler(MenuClick);
            MenuItem[] ctxSaveMenu = {
                                        new MenuItem("Open Image", eh) 
                                     };
            ContextMenu = new System.Windows.Forms.ContextMenu(ctxSaveMenu);
        }

        void MenuClick(object obj, EventArgs ea)
        {
            MenuItem mI = (MenuItem)obj;
            String str = mI.Text;
            if (str == "Open Image")
                LoadImage();
        }
        public override void ChildDisplay()
        {
            if (childDisplayFrm == null)
            {
                childDisplayFrm = new ChildDisplayForm();
                childDisplayFrm.Owner = this;
                childDisplayFrm.ShowInTaskbar = false;    
                childDisplayFrm.Hide();
            }
            if ( childDisplayFrm != null && childDisplayFrm.map != null)
            {
                childDisplayFrm.map.Dispose();
            }
            childDisplayFrm.map = new Bitmap(rcBone.Width, rcBone.Height);
            Graphics dcMem = Graphics.FromImage(childDisplayFrm.map);
            dcMem.Clear(Color.White);
            if (imgResize != null)
            {
                dcMem.DrawImage(imgResize, new Rectangle(0, 0, rcBone.Width, rcBone.Height), rcBone, GraphicsUnit.Pixel);
                dcMem.Dispose();
                childDisplayFrm.Size = new Size(rcBone.Width + SystemInformation.Border3DSize.Width*2,
                                                rcBone.Height + SystemInformation.Border3DSize.Width * 4+ SystemInformation.CaptionHeight+SystemInformation.MenuButtonSize.Height);
                childDisplayFrm.Show();
                childDisplayFrm.BringToFront();
                childDisplayFrm.Invalidate();
            }
            if (SystemInformation.WorkingArea.Width - childDisplayFrm.Width > MdiParent.Location.X + MdiParent.Width)
                childDisplayFrm.Location = new Point(MdiParent.Location.X + MdiParent.Width, MdiParent.Location.Y);
            else
                childDisplayFrm.Location = new Point(0, 0);
        }
        public void DrawImage(PaintStruct ps)
        {
            if (img != null)
            {
                if (imgResize != null)
                    imgResize.Dispose();
                if (ClientRectangle.Width > 0 && ClientRectangle.Height > 0)
                {
                    imgResize = new Bitmap(ClientRectangle.Width, ClientRectangle.Height);
                    Graphics dcTmp = Graphics.FromImage(imgResize);
                    dcTmp.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                    dcTmp.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                    dcTmp.DrawImage(img, ClientRectangle);
                    dcTmp.Dispose();

                    if (ps.isPaint)
                    {
                        Graphics dc = ps.dc;
                        dc.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                        dc.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                        dc.DrawImage(imgResize, ClientRectangle);
                    }
                    else
                    {
                        Graphics dc = CreateGraphics();
                        dc.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                        dc.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                        dc.DrawImage(imgResize, ClientRectangle);
                        dc.Dispose();
                    }
                }
            }
        }
        public void DrawRectangle(Graphics dc)
        {
            Pen p = new Pen(Brushes.Blue, 2); 
            dc.DrawRectangle(p, rcBone);
            
            dc.FillRectangle(Brushes.Blue, rcLT);
            dc.FillRectangle(Brushes.Blue, rcRT);
            dc.FillRectangle(Brushes.Blue, rcLB);
            dc.FillRectangle(Brushes.Blue, rcRB);

            
            //dc.DrawRectangle(p, rcLT);
            //dc.DrawRectangle(p, rcRT);
            //dc.DrawRectangle(p, rcBL);
            //dc.DrawRectangle(p, rcRB);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics dcPaint = e.Graphics;
            if (ClientRectangle.Width > 0 && ClientRectangle.Height > 0 && img != null )
            {
                //dcPaint.DrawImage(img, ClientRectangle);
                
                PaintStruct ps;
                ps.dc = e.Graphics;
                ps.isPaint = true;
                DrawImage(ps);
                //Pen p = new Pen(Brushes.Blue, 2); 
                //dcPaint.DrawRectangle(p, rcBone);
                DrawRectangle(dcPaint);
            }
            if (img == null)
            {
                //dcPaint.DrawString("Right click here to choose an Image", new Font("Tahoma", 23),new SolidBrush(Color.Blue), new PointF(0, 0));
                StringFormat stfRmt =  new StringFormat(StringFormatFlags.DisplayFormatControl);
                Brush br = new SolidBrush(Color.Black);
                RectangleF rcF = MdiParent.ClientRectangle;
                rcF.Width -= SystemInformation.VerticalScrollBarWidth;
                string str =  "If you do not Choose and Image now you can always Right click here to choose an Image later on";
                for (int j = 0; j <= 5; j++)
                {
                    dcPaint.DrawString(str, new Font("Tahoma", 23), br, rcF, stfRmt);
                    rcF.Offset(1, 1);
                }
                br.Dispose();
                br = new SolidBrush(Color.White);
                dcPaint.DrawString(str, new Font("Tahoma", 23), br, rcF, stfRmt);
            }
            //Pen penRed = new Pen(Color.Red, 4);
            //Pen penGreen = new Pen(Color.Green, 4);
            //dcPaint.DrawRectangle(penRed, rcOriginal);
            //dcPaint.DrawRectangle(penGreen, rcBegin);
            base.OnPaint(e);
        }
        public void LoadImage()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files(*.BMP;*.JPG;*.GIF;*.Tiff)|*.BMP;*.JPG;*.GIF;*.Tiff ";
            if (DialogResult.OK == ofd.ShowDialog())
            {
                img = Image.FromFile(ofd.FileName);
                strImgPath = ofd.FileName;
                //MessageBox.Show(strImgPath);
                Invalidate();
                Text = ofd.FileName;
                nDblClick = -1;
            }
            else
            {
                Text = "No Image selected";
            }
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            WindowState = FormWindowState.Normal;
            LoadImage();
        }
        protected override void OnClosing(CancelEventArgs e)
        {
            if(childDisplayFrm != null)
                childDisplayFrm.Close();

            if (img != null)
                img.Dispose();
            if (imgResize != null)
                imgResize.Dispose();
            base.OnClosing(e);
        }
        protected override void OnResize(EventArgs e)
        {
            PaintStruct ps;
            ps.dc = null;
            ps.isPaint = false;
            DrawImage(ps);
            if (img != null)
            {
                Graphics dc = CreateGraphics();
                DrawRectangle(dc);
                dc.Dispose();
            }
            base.OnResize(e);            
        }
    }

}