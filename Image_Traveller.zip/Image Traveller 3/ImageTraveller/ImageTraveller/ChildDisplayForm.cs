using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ImageTraveller
{
    public partial class ChildDisplayForm : Form
    {
        public Bitmap map;
        public ChildDisplayForm()
        {
            InitializeComponent();
            EnableContextMenu();
            Icon = new Icon(GetType(), "TravellerCat.ico");
        }
        void EnableContextMenu()
        {
            EventHandler eh = new EventHandler(MenuClick);
            MenuItem[] ctxSaveMenu = {
                                        new MenuItem("S&ave", eh) 
                                     };
            ContextMenu = new System.Windows.Forms.ContextMenu(ctxSaveMenu);
            InitializeMyMainMenu();
        }
        private void InitializeMyMainMenu()
        {
            EventHandler eh = new EventHandler(MenuClick);

            MainMenu mainMenu1 = new MainMenu();

            MenuItem SubItem1 = new MenuItem("&File");
            MenuItem SubItem11 = new MenuItem("S&ave", eh);
            SubItem1.MenuItems.Add(SubItem11);
            mainMenu1.MenuItems.Add(SubItem1);
            Menu = mainMenu1;
        }

        void SaveImage()
        {
            SaveFileDialog saveFlDlg = new SaveFileDialog();
            //saveFlDlg.Filter = "Jpeg (*.jpeg)|*.jpeg";
            saveFlDlg.Filter = "Save as a Jpeg file(*.jpeg)|*.jpeg|"+
                               "Save as a BMP file (*.bmp)|*.bmp|"+
                               "Save as a Tiff file(*.Tiff)|*.Tiff|"+
                               "Save as a Png file(*.Png)|*.Png";

            if(DialogResult.OK != saveFlDlg.ShowDialog())
                return;
            String Savefilename;
            Savefilename = saveFlDlg.FileName.ToString();

            MessageBox.Show(Savefilename);
            string strExtension = System.IO.Path.GetExtension(Savefilename);
            if (strExtension == ".jpeg")
            {
                map.Save(Savefilename, System.Drawing.Imaging.ImageFormat.Jpeg);

            }
            else if (strExtension == ".bmp")
            {
                map.Save(Savefilename, System.Drawing.Imaging.ImageFormat.Bmp);

            }
            else if (strExtension == ".Tiff")
            {
               map.Save(Savefilename, System.Drawing.Imaging.ImageFormat.Tiff);
            }
            else if (strExtension == ".Png")
            {
                map.Save(Savefilename, System.Drawing.Imaging.ImageFormat.Png);
            }
        }
        void MenuClick(object obj, EventArgs ea)
        {
            MenuItem mI = (MenuItem)obj;
            String str = mI.Text;
            if (str == "S&ave")
            {
                //MessageBox.Show("labamba");
                SaveImage();
                
            }
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics dc = e.Graphics;
            if (map != null)
            {
                dc.DrawImage(map, 0, 0);
            }

            base.OnPaint(e);
        }
        protected override void OnClosing(CancelEventArgs e)
        {
            ChildFrame frm = (ChildFrame)Owner;
            frm.childDisplayFrm = null;
            frm.Close();
            //MessageBox.Show(Owner.Text);
            base.OnClosing(e);
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
                Close();
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}